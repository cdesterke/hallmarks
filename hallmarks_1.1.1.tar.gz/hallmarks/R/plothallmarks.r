#' @title plothallmarks

#' @param font basic font size of the plot
#' @param label font size for labels of enrichment score
#' @param title string for the title of the graph
#' @usage plothallmarks(res, font=16,label=4,title="Enriched hallmarks")
#' @examples plothallmarks(res, font=16,label=4,title="Enriched hallmarks")


# plothallmarks(res, font=16,label=4,title="Enriched hallmarks")

plothallmarks<-function(res, font=16,label=4,title="Enriched hallmarks"){
colors_pal<-c("chartreuse3","cadetblue2","darkorange1","hotpink","goldenrod2",
"darkorchid2","lightblue","mistyrose3","coral2","deepskyblue1","darkseagreen3","lightsalmon3",
"lightcyan3")
  	if(!require(ggplot2)){
    	install.packages("ggplot2")
    	library(ggplot2)}


p=ggplot(data=res,aes(x=reorder(pathway,ES),y=ES,fill=class))+geom_bar(stat="identity")+
coord_flip()+theme_minimal()
p +  xlab("Genesets") + ylab("Normalized enrichment score")
p + scale_fill_manual(values=colors_pal)+
geom_text(aes(label=round(ES,2)),hjust=0, vjust=0.5,color="black",position= position_dodge(0),size=label,angle=0)+
xlab("Gene sets") + ylab("Enrichment score")+
ggtitle(title) +theme(text = element_text(size = font))

}
