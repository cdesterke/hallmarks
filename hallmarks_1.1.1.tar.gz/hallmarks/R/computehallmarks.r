#' @title computehallmarks

#' @param group group column from phenotype file
#' @param control string defining control in pheno$group data
#' @usage res<-computehallmarks(custom,q=0.05)
#' @examples res<-computehallmarks(custom,q=0.05)









computehallmarks<-function(custom,q=0.05){

  	if(!require(dplyr)){
    	install.packages("dplyr")
    	library(dplyr)}

	data(ident)
	data(genesplit)

	hallmarks <- ident$pathway
	hallmarks <- as.data.frame(hallmarks)
	for(i in 1:length(genesplit)){
		hallmarks$intersect[i]<-length(intersect(custom,genesplit[[i]]))
			}
	hallmarks$input<-length(custom)
	for(i in 1:length(genesplit)){
		hallmarks$geneset[i]<-length(genesplit[[i]])
			}
	hallmarks$totaldb<-length(unique(unlist(genesplit)))


	hallmarks<-hallmarks[(hallmarks$intersect != "0"),]
	df<-hallmarks[with(hallmarks,order(-intersect)),]

	row.names(df)<-df$hallmarks
	df$hallmarks<-NULL

	res1 <- NULL
	for (i in 1:nrow(df)){
  	table <- matrix(c(df[i,1], df[i,2], df[i,3], df[i,4]), ncol = 2, byrow = TRUE)
  	o <- fisher.test(table, alternative="two.sided")$estimate
  	# save all odds in a vector
  	res1 <- c(res1,o)
	}
	df$ES <- res1



	res2 <- NULL
	for (i in 1:nrow(df)){
  	table <- matrix(c(df[i,1], df[i,2], df[i,3], df[i,4]), ncol = 2, byrow = TRUE)
  	p <- fisher.test(table, alternative="two.sided")$p.value
  	# save all p values in a vector
  	res2 <- c(res2,p)
	}
	df$pvalues <- res2

	df$qvalues<-p.adjust(df$pvalues,method="fdr")

	df<-df[with(df,order(qvalues)),]
	df<-df[(df$qvalues <= q),]

	#ident%>%select(-link)->ident

	df$pathway<-row.names(df)

	ident%>%right_join(df,by="pathway")->df

	return(df)
}





