#' @title heatjaccard

#' @param custom your custom gene set
#' @param res results from computehallmarks performed on custom
#' @param xmarg margin size in X
#' @param ymarg margin size in Y
#' @usage heatjaccard(custom,res,xmarg=22,ymarg=22)
#' @examples data(custom)
#' @examples res<-computehallmarks(custom)
#' @examples heatjaccard(custom,res,xmarg=22,ymarg=22)


heatjaccard<-function(custom,res,xmarg=22,ymarg=22){

data(ident)
data(genesplit)

## heatmap on significant
inter<-rep(NA,nrow(ident))
inter<-as.list(inter)
for(i in 1:length(genesplit)){
if (length(intersect(custom,genesplit[[i]]))>0){
inter[[i]]<-intersect(custom,genesplit[[i]])}
}

names(inter)<-ident$pathway

inter<-lapply(inter, function(z){ z[!is.na(z) & z != "NA"]})
inter<-inter[lapply(inter,length)>0]
## subset list intersection with significant pathways

sig=res$pathway
intersig<-inter[sig]

result <- sapply(intersig,function(x) 
            sapply(intersig,function(y,x)length(intersect(x,y))/length(union(x,y)),x))
 
result<-as.matrix(result)          
heatmap(result,margins = c(xmarg, ymarg),cexRow=1,cexCol=1)

}

